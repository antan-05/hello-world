<?php
    $myPDO = new PDO('mysql:host=localhost;', 'antan', 'buddha123') or die('could not connect the server');
?>