 <?php
       
      //$nextWeek = time() + (7 * 24 * 60 * 60);
      // 7 days; 24 hours; 60 mins; 60 secs
      //echo 'Now:       '. date('Y-m-d'). PHP_EOL;   
      //echo 'Next Week: '. date('Y-m-d', $nextWeek) ."\n";
      // or using strtotime():
      //echo 'Next Week: '. date('Y-m-d', strtotime('+2 week')) ."\n";
      echo nl2br("Welcome \natcasesort(array)to PHP");
      echo "hiiii";

 ?>